<?php
require_once 'lib/connect_db.php';
require_once "lib/handle.php";
$mid = $_GET['id'];
$sql="delete from messages where id=".$mid;
$url = "message.php";
if ($link->query($sql)) {
    echo "<script language='JavaScript' type='text/javascript'>";
    echo "alert(\"删除成功，即将转到留言板主页\")";
    echo "</script>";
    jump($url);
}else{
    echo "<script language='JavaScript' type='text/javascript'>";
    echo "alert(\"删除失败\")";
    echo "window.location.href='$url'";
    echo "</script>";

}
mysqli_close($link);
?>