<?php
header("Content-type: text/html; charset=utf-8");

require_once "lib/Judge.php";
require_once "lib/Upload_Profile_Picture.php";
require_once "lib/Handle_Password.php";
require_once "lib/connect_db.php";


if (isset($_POST["sub"])) {
    $username = $_POST["username"];
    $userpwd = $_POST["userpwd"];
    $conpwd = $_POST["conpwd"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $sex = $_POST["sex"];
    $insterests = $_POST["insterests"];
    $hobby = null;
    for ($i = 0; $i < count($insterests); $i++) {
        $hobby = $insterests[$i] . " " .$hobby ;
    }

    if (empty($username) || empty($userpwd) || empty($conpwd) || empty($email) || empty($phone) || empty($sex) || empty($hobby)) {
        error_back("填写信息不能为空！");
    } else {
        judge_username();
        compare_password();
        judge_phone();
        $userpwd = md5_password();
        $profile = upload_profile();
        $remarks = judge_remarks();


        $sql = "INSERT INTO 
                `user` 
                (`name`, `password`, `email`, `phone`, `sex`, `hobby`, `profile`, `remarks`)
                VALUES 
                ('$username', '$userpwd', '$email', '$phone', '$sex', '$hobby', '$profile', '$remarks')";
        $re = $link->query($sql);
        if (mysqli_affected_rows($link) !== 1) {
            error_back("注册失败。");
        }else{
            echo "<script type=\"text/javascript\">
                    alert(\"注册成功！即将跳转到登陆界面。\")
                    </script>";
            jump("login.php");
        }
    }

}
mysqli_close($link);
?>