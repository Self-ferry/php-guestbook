<html>
<head>
    <title>留言修改</title>
    <h2><a href="message.php">返回主页</a></h2>
</head>
<body>


<?php
require_once "lib/connect_db.php";
require_once "lib/handle.php";

$mid=$_GET["id"];
$sql="SELECT * FROM messages WHERE id =".$mid;
$result=$link->query($sql);

while ($rs=mysqli_fetch_array($result)){

?>
<form METHOD="POST" ACTION="preEdit.php">
    <input type="hidden" name="id" value="<?=$rs["id"]?>">
    用户：<?=$rs["username"]?><br />
    标题：<input type="text" name="title" value="<?=$rs["title"]?>"><br />
    内容：<textarea name="content" rows="15" COLS="80"><?=$rs["content"]?></textarea><br />
    <input type="submit" name="submit" value="修改">
</form>

<?php }?>

<?php
if (isset($_POST["submit"])) {
    $sql = "update messages set title='$_POST[title]',content='$_POST[content]',time =now() where id='$_POST[id]'";
    $link->query($sql);
    $url = "message.php";
    echo "<script language='javascript' type='text/javascript'>";
    echo "window.location.href='$url'";
    echo "</script>";
}
mysqli_close($link);
?>
</body>
</html>



