
<?php
//header("Content-type: text/html; charset=utf-8");

global $link;
$link= new mysqli('127.0.0.1','root','123456','guestbook');

if (!$link) {
    die("Connection failed: " . mysqli_connect_error());
}
$link->query("set names 'utf8'")
?>
