
<?php

header("Content-type: text/html; charset=utf-8");

require_once "handle.php";

function upload_profile(){
    if (!empty($_FILES['profile']['name'])) {
        $username=$_POST["username"];
        $newname=$_FILES['profile']['name'];
        $dest="./userimg/$username$newname";
        move_uploaded_file($_FILES['profile']['tmp_name'],$dest);
        return $dest;
    }
    else{
        echo "<script>alert(\"没有上传头像，将使用默认头像\")</script>";
        jump("register.php");
        $dest="./userimg/default.bmp";
        return $dest;
    }
}
function update_profile($filename,$username){
        $newname=$_FILES[$filename]['name'];
        $dest="./userimg/$username$newname";
        move_uploaded_file($_FILES[$filename]['tmp_name'],$dest);
        return $dest;
}

?>