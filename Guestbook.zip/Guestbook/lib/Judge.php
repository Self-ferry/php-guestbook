
<?php


require_once "handle.php";
require_once "connect_db.php";


global $link;


function judge_username()
{

    global $link;
    $username = $_POST["username"];
    $sql= "select name from user where name=\"$username\"";
    $link->query($sql);
    if(!mysqli_affected_rows($link)==0){
        error_back("用户名已存在");
    }
}



function judge_phone()
{
    global $link;
    $phone = $_POST["phone"];
    $sql= "select name from user where name=\"$phone\"";
    $link->query($sql);
    if(!mysqli_affected_rows($link)==0){
        error_back("手机号已注册");
    }
}


function judge_remarks()
{
    if (empty($_POST["remark"])) {
        return "此人很懒，什么也没写。";
    }
    else{
        return $_POST["remark"];
    }
}
?>