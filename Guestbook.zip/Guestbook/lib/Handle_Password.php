<?php
require_once "handle.php";
function compare_password()
{
    if($_POST["userpwd"] !== $_POST["conpwd"]){
        error_back("两次输入的密码不一样");
    }
}

function md5_password(){
    $password = $_POST["userpwd"];
    return md5($password);
}

function md5_verification(){
    $password = $_POST["password"];
    return md5($password);
}
?>