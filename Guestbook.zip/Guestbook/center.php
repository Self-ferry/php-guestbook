<html>
<head>
    <meta charset="UTF-8">
    <title>个人中心</title>
    <h1>个人中心</h1>
    <?php
    $user = $_GET['user'];
    echo "<b>$user 你好！！</b>";
    ?>
    <b><a href="message.php">返回主页</a></b>
    <hr>

</head>
<body>
<?php
require_once "lib/connect_db.php";
$sql = "SELECT email,phone,sex,hobby,profile,remarks  FROM `user`WHERE name='$user'";
$result = $link->query($sql);
$result = mysqli_fetch_assoc($result);
?>
<label>头像：</label>
<br>
<img src="<?=$result['profile']?>" width="200" height="200">

<form method="post" enctype="multipart/form-data">
<label>上传新头像：</label>
<input type="file" name="image" >
    <br>
<label>E-mail：</label>
<input type="text" name="email" value="<?= $result['email'] ?>">
<br>
<label>手机号：</label>
<input type="text" name="phone" value="<?= $result['phone'] ?>">
<br>
<label>性别：</label>
<input type="text" name="sex" value="<?= $result['sex'] ?>">
<br>
<label>爱好：</label>
<input type="text" name="hobby" value="<?= $result['hobby'] ?>">
<br>
<label>备注信息：</label>
<br>
<textarea name="remarks" rows="15" COLS="80">
    <?= $result['remarks'] ?>
</textarea>

<br>
<input type="submit" name="submit" value="修改信息">
</form>
<?php
require_once "lib/connect_db.php";
require_once "lib/Upload_Profile_Picture.php";

if (isset($_POST['submit'])){
    $remarks = $_POST['remarks'];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $sex = $_POST["sex"];
    $hobby = $_POST['hobby'];
    if (!empty($_FILES['image']['name'])){
            $image = update_profile("image",$user);

    }else{

        $image = $result['profile'];
    }

    $sql = "UPDATE `user` 
            SET 
            `remarks` = '$remarks',  
            `phone` = '$phone', 
            `profile` = '$image',
            `email` = '$email',
            `sex` = '$sex',
            `hobby` = '$hobby' 
            WHERE `name` = '$user'";
    if ($link->query($sql)){
        $url = "message.php";
        echo "<script language='javascript' type='text/javascript'>";
        echo "alert('修改信息成功，即将返回主页!');";
        echo "window.location.href='$url'";
        echo "</script>";
    }else{
       error_back("修改失败");
    }

}
mysqli_close($link);
?>
</body>
</html>


