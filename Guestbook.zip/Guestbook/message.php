<?php session_start() ?>

<html>
<head>
    <title>留言板主页</title>
    <STYLE>
        /*html {*/
        /*    overflow: auto;*/
        /*}*/
        body{
            background-image: url("bgimg.png");
            background-size: 100%;
        }
        iframe{
            border: 1px solid #2b669a;
        }
    </STYLE>
</head>
<body>
<h1 align="center"><font color="#ff7f50">留言板主页</font></h1>
<hr>

<?php
require_once "./lib/handle.php";

if (!isset($_SESSION["islogin"])){
    error_back("未授权登陆");

    die();
}
if($_SESSION["islogin"] == "1"){
$username = $_SESSION["username"];
}
?>

<div class="userinfo">
<?php
echo "<font color='#7fffd4'>欢迎$username ！！</font>";
echo "<b><a href=\"center.php?user=$username\">个人中心</a></b>";
echo "<a href='loginout.php'>
<b>退出登录</b>
</a>";
echo "<hr>";
?>
</div>
<font color="#fff8dc"><h2 align="center">留言记录</h2></font>
<table width=500 border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#add3ef">
    <?php
    require_once "lib/connect_db.php";
    $sql="select * from messages order by id";
    $query=$link->query($sql);
    while ($row=mysqli_fetch_array($query)){
        ?>
        <tr bgcolor="#eff3ff">
            <td>
                标题：<font color="red"><?=$row["title"]?></font>

                用户：<font color="red"><?=$row["username"] ?></font>
                <?php if($row['username']==$username){?>
                <div align="right">
                    <a href="preEdit.php?id=<?=$row["id"]?>">编辑</a>
                    &nbsp;&nbsp;|&nbsp;&nbsp;
                    <a href="delete.php?id=<?=$row["id"]?>">删除</a>
                </div></td>
            <?php }?>
        </tr>
        <tr bgColor="#ffffff">
            <td>内容：<?=$row["content"]?></td>
        </tr>
        <tr bgColor="#ffffff">
            <td><div align="right">发表日期：<?=$row["time"]?></div></td>
        </tr>
    <?php }?>

</table>


<div>
    <hr>
    <font color="#9932cc"><h2>发表留言</h2></font>
<form method="POST" action="message.php">
    <font color="aqua"> 用户： <?=$username?></font><br />
    <font color="aqua">标题：</font><input type="text" name="title"/><br />
    <font color="aqua">内容：</font><br><TEXTAREA name="content" rows="10" cols="80"></TEXTAREA><br />
    <input type="submit" name="submit" value="发表留言" />
</form>
</div>
<?php
include "lib/connect_db.php";

if(isset($_POST['submit'])){
    $sql="INSERT INTO messages(`id`,`title`,`content`,`username`,`time` ) VALUES (NULL,  '$_POST[title]', '$_POST[content]','$username', now())";
    $link->query($sql);
    $url = "message.php";
    echo "<script language='javascript' type='text/javascript'>";
    echo "window.location.href='$url'";
    echo "</script>";
}
mysqli_close($link);
?>

</body>
</html>

