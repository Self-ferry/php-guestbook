<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>登陆</title>
</head>
<body>
<form action="login.php" method="post">
    <h3 align="center">登录</h3>
    <table  width="230" align="center" border="2">
        <tr>
            <td>用户名</td>
            <td><input type="text" name="username" /></td>
        </tr>
        <tr>
            <td>密码</td>
            <td><input type="password" name="password" /></td>
        </tr>
        <tr>
            <td>登陆</td>
            <td><input type="submit" name="login" value="登陆">
                <input type="submit" name="register" value="注册账号">
            </td>
        </tr>
    </table>
</form>

<?php
require_once "./lib/connect_db.php";
require_once "./lib/Handle_Password.php";

if (!session_start()){
    session_start();
}

if (isset($_POST["login"])) {
    $username = $_POST["username"];
    $password = $_POST["password"];
    if(empty($username)||empty($password)){
        error_back("账号或密码不能为空");
    }
    $password = md5_verification();
    $sql = "SELECT * FROM `user` WHERE name=\"$username\" and password=\"$password\"";
    $re = $link->query($sql);
    if (mysqli_num_rows($re)) {

        $_SESSION["islogin"] = "1";
        $_SESSION["username"] = $username;

        echo "<script type='text/javascript'>alert('登陆成功！');</script>";
        echo "<script type='text/javascript'>
                window.location.href= \"message.php\";
              </script>";
    }else{
        error_back("账号或密码错误");
    }
}

if (isset($_POST["register"])){
    echo "<script type='text/javascript'>
                window.location.href= \"register.html\";
              </script>";
}
mysqli_close($link);
?>

</body>
</html>





