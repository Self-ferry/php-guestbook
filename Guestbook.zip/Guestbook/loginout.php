<html>
<head>
    <title>退出账号</title>
</head>
<body>
<font color="#dc143c"><h1 align="center">正在退出账号中</h1></font>
<?php
require_once "./lib/handle.php";
if (!session_start()){
    session_start();
}
session_destroy();

jump("login.php");

?>

</body>
</html>


