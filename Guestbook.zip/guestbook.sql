-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1:3306
-- 生成日期： 2020-12-16 02:06:04
-- 服务器版本： 5.7.24
-- PHP 版本： 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `guestbook`
--

-- --------------------------------------------------------

--
-- 表的结构 `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `title` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `messages`
--

INSERT INTO `messages` (`id`, `title`, `content`, `username`, `time`) VALUES
(1, 'study', 'Provisional headers are shown\r\n2020年12月15日10:56:50<br>\r\n2020年12月15日11:04:22<br>\r\n2020年12月15日11:04:58\r\n2020年12月15日11:08:11\r\n2020年12月15日19:53:17\r\nOK', 'admin', '2020-12-15 19:54:38'),
(2, '《静夜思》李白', '窗前明月光，疑是地上霜。\r\n举头望明月，低头思故乡。', 'admin', '2020-12-15 10:29:20'),
(4, '考前必背单词', 'absolute a.绝对的；完全的；无疑的<br>\r\n……<br>\r\n……<br>\r\n……<br>\r\n2020年12月15日11:52:39', '小红', '2020-12-15 11:51:08'),
(6, '《离散数学》', '周四下午16:40-18：40考试', '小红', '2020-12-15 19:10:21'),
(7, '《科技英语》', '7天后考试', '小红', '2020-12-15 19:22:08'),
(10, '图的概念', 'G=（V,E）V节点的集合，E边的集合。', 'admin', '2020-12-16 09:41:18');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `sex` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `hobby` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `profile` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT './userimg/default.bmp',
  `remarks` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '此用户很懒，什么都没写。',
  PRIMARY KEY (`id`,`name`,`phone`,`profile`),
  UNIQUE KEY `name` (`name`,`phone`,`profile`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`id`, `name`, `password`, `email`, `phone`, `sex`, `hobby`, `profile`, `remarks`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '886@qq.com', '33', 'man', 'sing jump rap ', './userimg/admin200.jpg', '666  你好！！!!!'),
(2, '小红', '21232f297a57a5a743894a0e4a801fc3', '666@qq.com', '886886', 'woman', 'sing ', './userimg/小红20200620010458420.jpg', '此人很懒，什么也没写。'),
(3, '小张', 'e10adc3949ba59abbe56e057f20f883e', '777@163.com', '33', 'man', 'jump rap ', './userimg/小张200.jpg', '    此人很懒，什么也没写。');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
